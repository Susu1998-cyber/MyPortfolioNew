module.exports = [
"[project]/OneDrive/Desktop/Myportfolio/app/favicon.ico (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.4f51514a.ico");}),
"[project]/OneDrive/Desktop/Myportfolio/app/favicon.ico.mjs { IMAGE => \"[project]/OneDrive/Desktop/Myportfolio/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Desktop$2f$Myportfolio$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Desktop/Myportfolio/app/favicon.ico (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Desktop$2f$Myportfolio$2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$29$__["default"],
    width: 717,
    height: 717
};
}),
];

//# sourceMappingURL=OneDrive_Desktop_Myportfolio_app_893e3486._.js.map