var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sendEmail/route.js")
R.c("server/chunks/[root-of-the-server]__1daa358d._.js")
R.c("server/chunks/[root-of-the-server]__91ccd6a8._.js")
R.c("server/chunks/[root-of-the-server]__9bd68279._.js")
R.m(10811)
R.m(16992)
module.exports=R.m(16992).exports
