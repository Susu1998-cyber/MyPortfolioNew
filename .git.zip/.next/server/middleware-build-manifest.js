globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/fa93d_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9535cb3d._.js",
    "static/chunks/fa93d_next_dist_compiled_react-dom_9d27d68b._.js",
    "static/chunks/fa93d_next_dist_compiled_next-devtools_index_0a528f48.js",
    "static/chunks/fa93d_next_dist_compiled_ac0033af._.js",
    "static/chunks/fa93d_next_dist_client_bc42635d._.js",
    "static/chunks/fa93d_next_dist_53363b73._.js",
    "static/chunks/fa93d_@swc_helpers_cjs_253b7315._.js",
    "static/chunks/OneDrive_Desktop_Myportfolio_a0ff3932._.js",
    "static/chunks/turbopack-OneDrive_Desktop_Myportfolio_dd7a22f9._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];