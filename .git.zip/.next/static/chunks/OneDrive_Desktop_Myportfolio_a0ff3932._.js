(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_9535cb3d._.js",
  "static/chunks/fa93d_next_dist_compiled_react-dom_9d27d68b._.js",
  "static/chunks/fa93d_next_dist_compiled_next-devtools_index_0a528f48.js",
  "static/chunks/fa93d_next_dist_compiled_ac0033af._.js",
  "static/chunks/fa93d_next_dist_client_bc42635d._.js",
  "static/chunks/fa93d_next_dist_53363b73._.js",
  "static/chunks/fa93d_@swc_helpers_cjs_253b7315._.js"
],
    source: "entry"
});
