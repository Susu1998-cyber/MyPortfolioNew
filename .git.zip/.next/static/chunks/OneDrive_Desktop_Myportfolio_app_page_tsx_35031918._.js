(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/OneDrive_Desktop_Myportfolio_b1c4f232._.js",
  "static/chunks/fa93d_next_dceebcae._.js",
  "static/chunks/fa93d_react-icons_hi_index_mjs_cda4475d._.js",
  "static/chunks/fa93d_react-icons_fa_index_mjs_087ce7cd._.js",
  "static/chunks/fa93d_react-icons_si_index_mjs_0156f75f._.js",
  "static/chunks/fa93d_react-icons_lib_6d9b7f9f._.js",
  "static/chunks/fa93d_axios_lib_80a04802._.js",
  "static/chunks/fa93d_react-fast-marquee_dist_index_6496bf0f.js"
],
    source: "dynamic"
});
