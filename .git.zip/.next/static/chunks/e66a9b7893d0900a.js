__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e9b5ba954143daaf.js",
  "static/chunks/b03f57cb15c358d2.js",
  "static/chunks/turbopack-7163355299a34873.js"
])
