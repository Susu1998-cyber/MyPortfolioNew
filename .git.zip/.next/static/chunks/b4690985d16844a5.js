__turbopack_load_page_chunks__("/_error", [
  "static/chunks/1df7edbe228d1cf9.js",
  "static/chunks/b03f57cb15c358d2.js",
  "static/chunks/turbopack-68a9d2f4bb1b4193.js"
])
