(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/fa93d_next_dist_compiled_next-devtools_index_2d757a38.js",
  "static/chunks/fa93d_next_dist_compiled_b42c99d0._.js",
  "static/chunks/fa93d_next_dist_shared_lib_3664840e._.js",
  "static/chunks/fa93d_next_dist_client_77243f2c._.js",
  "static/chunks/fa93d_next_dist_41e533c1._.js",
  "static/chunks/fa93d_next_error_4ee4b8ad.js",
  "static/chunks/[next]_entry_page-loader_ts_50ed8ae6._.js",
  "static/chunks/fa93d_react-dom_b575ca6f._.js",
  "static/chunks/fa93d_e83e5cdf._.js",
  "static/chunks/[root-of-the-server]__fb2c7e5f._.js"
],
    source: "entry"
});
